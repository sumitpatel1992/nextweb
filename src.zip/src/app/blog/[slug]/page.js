// app/blog/[slug]/page.js
import { notFound } from "next/navigation";

const posts = [
  {
    title: "First Post",
    content: "This is the full content of the first post",
    slug: "first-post",
  },
  {
    title: "Second Post",
    content: "This is the full content of the second post",
    slug: "second-post",
  },
];

export async function generateStaticParams() {
  return posts.map((post) => ({ slug: post.slug }));
}

export default function BlogPost({ params }) {
  const post = posts.find((p) => p.slug === params.slug);
  if (!post) {
    notFound(); // Returns 404 if the post is not found
  }

  return (
    <article className="prose max-w-none">
      <h1>{post.title}</h1>
      <p>{post.content}</p>
    </article>
  );
}
