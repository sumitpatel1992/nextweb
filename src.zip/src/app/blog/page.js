// app/blog/page.js
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

const posts = [
  {
    title: "First Post",
    description: "This is the first blog post",
    slug: "first-post",
  },
  {
    title: "Second Post",
    description: "This is the second blog post",
    slug: "second-post",
  },
];

export default function BlogPost() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {posts.map((post) => (
        <Card key={post.slug} className="p-4">
          <h2 className="text-xl font-semibold">{post.title}</h2>
          <p>{post.description}</p>
          <a href={`/blog/${post.slug}`} className="text-blue-500">
            Read more
          </a>
        </Card>
      ))}
    </div>
  );
}
