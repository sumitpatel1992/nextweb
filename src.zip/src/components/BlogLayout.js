// components/BlogLayout.js

export default function BlogLayout({ children }) {
  return (
    <div>
      <main>{children}</main>
    </div>
  );
}
